# sarah - widget.js - V4.0 Singleton Strike

// Global singleton - do NOT use new constructor
window.vapiSDK = window.vapiSDK || null;

const VAPI_PUBLIC_KEY = "3b065ff0-a721-4b66-8255-30b6b8d6daab";
const SARAH_ASSISTANT_ID = "1a797f12-e2dd-4f7f-b2c5-08c38c74859a";

function initVapi() {
    if (!window.vapiSDK) {
        // Load SDK if not present (fallback)
        const script = document.createElement('script');
        script.src = "https://cdn.jsdelivr.net/gh/VapiAI/html-script-tag@latest/dist/assets/index.js";
        script.onload = () => {
            window.vapiSDK.run({
                apiKey: VAPI_PUBLIC_KEY,
                assistant: SARAH_ASSISTANT_ID,
                config: {
                    position: "bottom-right",
                    offset: "20px",
                    width: "50px",
                    height: "50px"
                }
            });
            console.log('[Sovereign Voice V4.0] SDK Loaded & Initialized');
        };
        document.head.appendChild(script);
    } else {
        window.vapiSDK.run({
            apiKey: VAPI_PUBLIC_KEY,
            assistant: SARAH_ASSISTANT_ID,
            config: { position: "bottom-right", offset: "20px", width: "50px", height: "50px" }
        });
    }
}

// Global call function - always available
window.startSarahCall = function () {
    if (window.vapiSDK && window.vapiSDK.start) {
        window.vapiSDK.start(SARAH_ASSISTANT_ID);
        console.log("Sarah Voice Started!");
    } else {
        // Fallback if SDK hasn't loaded yet
        console.log("Vapi SDK not ready, retrying init...");
        initVapi();
        alert("Sarah is loading... try again in a moment.");
    }
};

// Auto-init on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initVapi);
} else {
    initVapi();
}
